import  './About.css';
function About()
{
    return(
        <div className="myAbout">
            <ins>This is my about js ins for underline</ins>
            </div>
    );
}
export default About;